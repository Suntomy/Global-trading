const health = document.getElementById("health");
const banks = document.getElementById("bank");
const account = document.getElementById("account");
const verification = document.getElementById("verification");

async function loadStatus() {
  try {
    const r = await fetch("/api/health");
    const d = await r.json();
    health.textContent =
      `Backend: ${d.status}; Provider configured: ${d.providerConfigured}; ` +
      `Broker data: not connected; Withdrawals: locked.`;
  } catch {
    health.textContent = "Backend unavailable.";
  }

  try {
    const r = await fetch("/api/brokers");
    document.getElementById("brokers").textContent =
      JSON.stringify(await r.json(), null, 2);
  } catch {
    document.getElementById("brokers").textContent = "Broker service unavailable.";
  }
}

async function loadBanks() {
  try {
    const r = await fetch("/api/ng/banks");
    const d = await r.json();
    banks.innerHTML = "";

    if (!r.ok || !Array.isArray(d.banks) || !d.banks.length) {
      banks.add(new Option("Bank list unavailable — configure provider", ""));
      return;
    }

    banks.add(new Option("Select a bank", ""));
    for (const b of d.banks) {
      if (b.code && b.name) {
        banks.add(new Option(b.name, b.code));
      }
    }
  } catch {
    banks.innerHTML = "";
    banks.add(new Option("Could not load banks", ""));
  }
}

document.getElementById("verify").addEventListener("click", async () => {
  const bankCode = banks.value;
  const accountNumber = account.value.trim();

  if (!bankCode || !/^[0-9]{10}$/.test(accountNumber)) {
    verification.textContent = "Select a bank and enter a 10-digit account number.";
    return;
  }

  verification.textContent = "Checking with provider...";

  try {
    const r = await fetch("/api/ng/resolve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ bankCode, accountNumber })
    });
    const d = await r.json();

    verification.textContent = d.verified
      ? `Verified account name: ${d.accountName}`
      : `Not verified: ${d.error || "Provider did not verify account."}`;
  } catch {
    verification.textContent = "Provider connection failed.";
  }
});

loadStatus();
loadBanks();
